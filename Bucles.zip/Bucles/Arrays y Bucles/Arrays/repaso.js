const numeros = [];
numeros = Math.floor(Math.random()*100);

function crear() {
    
}