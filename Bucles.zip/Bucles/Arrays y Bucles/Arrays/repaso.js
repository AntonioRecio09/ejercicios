let n = [];
let suma = 0;
let media = 0;
let mayor = 0;
let menor = 100;
function crear() {
    let count = document.getElementById("count").value;
    n = [];
    suma = 0 ;
    let mayor = 0;
    let menor = 100;
    for (let i = 0; i < count; i++) {
        let num = Math.ceil(Math.random()*100);
        n.push(num);
        suma = suma + num;
        if (num>mayor) {
            mayor = num;
        } 
        if (num<menor) {
            menor = num;
        } 
        if (num%2==0) {
            document.getElementById("rep6").innerHTML += num + ", ";       
        }
    }
    media = suma/count;        
    document.getElementById("rep1").innerHTML = n.join(", ");
    document.getElementById("rep2").innerHTML = suma;
    document.getElementById("rep3").innerHTML = media.toFixed(2);
    document.getElementById("rep4").innerHTML = mayor;    
    document.getElementById("rep5").innerHTML = menor;      
}

